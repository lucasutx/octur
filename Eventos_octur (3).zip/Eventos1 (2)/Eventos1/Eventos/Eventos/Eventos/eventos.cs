﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Eventos
{
    internal class eventos
    {
        public string NomeEvento { get; set; }
        public string Categoria { get; set; }
        
       

    }
}
