﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FireSharp.Config;
using FireSharp.Response;
using FireSharp.Interfaces;
using FireSharp;

namespace Eventos
{
    public partial class Form1 : Form
    {
        public object v { get; private set; }

        public Form1()
        {
            InitializeComponent();
        }

        IFirebaseConfig fcon = new FirebaseConfig()
        {
            AuthSecret = "ljWWL5kS1LbDpeDoKMHz8nvwGbgfAlke3G1soPrw",
            BasePath = "https://octur-2107c-default-rtdb.firebaseio.com/"
        };
        private FirebaseClient eventos;

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                eventos = new FireSharp.FirebaseClient(fcon);
            }
            catch
            {
                MessageBox.Show("Sem conexão");
            }
        }

        private IFirebaseConfig GetFcon()
        {
            return fcon;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            eventos ev1 = new eventos()
            {
                NomeEvento = textBox1.Text,
                Categoria = comboBox1.Text


            };

            var setter = eventos.Set("EventosList/" + textBox1.Text, ev1);
            MessageBox.Show("Cadastrado com sucesso");

        
                
                
                
         }

        private void button7_Click(object sender, EventArgs e)
        {
            Form2 telaPefil = new Form2();
            telaPefil.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            var result = eventos.Get("EventosList/" + textBox1.Text);

            eventos ev1 = result.ResultAs<eventos>();

            textBox1.Text = ev1.NomeEvento;
            comboBox1.Text = ev1.Categoria;
            MessageBox.Show("Pesquisa realizada com sucessso");

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Presença confirmada com sucesso");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Presença não confirmada");
        }

       
    }
}