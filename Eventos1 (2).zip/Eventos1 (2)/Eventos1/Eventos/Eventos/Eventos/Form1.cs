﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FireSharp.Config;
using FireSharp.Response;
using FireSharp.Interfaces;
using FireSharp;

namespace Eventos
{
    public partial class Form1 : Form
    {
        public object v { get; private set; }

        public Form1()
        {
            InitializeComponent();
        }

        IFirebaseConfig fcon = new FirebaseConfig()
        {
            AuthSecret = "ljWWL5kS1LbDpeDoKMHz8nvwGbgfAlke3G1soPrw",
            BasePath = "https://octur-2107c-default-rtdb.firebaseio.com/"
        };

        IFirebaseConfig client;
        private FirebaseClient eventos;

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                eventos = new FireSharp.FirebaseClient(fcon);
            }
            catch
            {
                MessageBox.Show("Verifique sua internet");

            }
        }

            private IFirebaseConfig GetFcon()
        {
            return fcon;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            eventos ev1 = new eventos()
            {

                NomeEvento = textBox1.Text,
                Categoria = comboBox1.Text


            };
                
         }



        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {

        }
    }
    }
